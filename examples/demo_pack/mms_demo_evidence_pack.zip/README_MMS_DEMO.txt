MapMyStandards Demo Evidence Pack (Paraphrased / Non-Official)

Files in this archive:
- positions.csv
- org_units.csv
- evidence_snippets.csv
- program_review_template.csv
- standards_SACSCOC_template.json
- standards_NWCCU_template.json

Usage Summary:
1) Import one or both standards via /api/standards/import
2) Upload CSV evidence files
3) Run mapping, gap analysis, and narrative generation

Disclaimer: Paraphrased demo subset – NOT official standards text.